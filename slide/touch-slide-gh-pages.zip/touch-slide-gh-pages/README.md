Touch Slide
-----------

A slide widget supports both PC and touch device.

http://myst729.github.io/touch-slide/
