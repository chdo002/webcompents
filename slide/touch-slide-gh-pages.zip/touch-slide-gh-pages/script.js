function Slide(node, timing, fallback) {

  var ele = document.getElementById(node),
      slider = ele.getElementsByTagName('ul')[0],
      len = ele.getElementsByTagName('li').length,
      sWid = ele.offsetWidth,
      frag = document.createElement('p'),
      idx = 0,
      idn = 0,
      auto,
      threshold = {'auto': timing || 3000, 'timer': 100, 'disp': 10},
      stat = {'posA': 0, 'posB': 0, 'posM': 0, 'thresholdA': 0, 'thresholdB': 0, 'interval': 300, 'flag': true, 'evt': true},
      evt = ('ontouchstart' in document) ? {'start': 'touchstart', 'move': 'touchmove', 'end': 'touchend'} : ((fallback == 'drag') ? {'start': 'dragstart', 'move': 'dragover', 'end': 'dragend'} : {'start': 'mousedown', 'move': 'mousemove', 'end': 'mouseup'});

  var start = function(e) {
    if(evt.start == 'mousedown') {
      e.preventDefault();
      e.stopPropagation();
      stat.flag = false;
    }
    clearInterval(auto);
    slider.style.webkitTransition = 'none';
    stat.posA = e.touches ? e.touches[0].pageX : e.pageX;
    stat.thresholdA = new Date();
  };

  var move = function(e) {
    if(evt.start == 'mousedown' && stat.flag) {
      return false;
    }
    stat.posB = e.touches ? e.touches[0].pageX : e.pageX;
    stat.thresholdB = new Date();
    if(Math.abs(stat.posA - stat.posB) > stat.posM) {
      stat.posM = Math.abs(stat.posA - stat.posB);
    }
    if(evt.start == 'touchstart' && stat.posM < threshold.disp) {
      stat.evt = false;
    } else if(stat.evt) {
      e.preventDefault();
      e.stopPropagation();
      if(stat.thresholdB - stat.thresholdA < threshold.timer) {
        if((stat.posA < stat.posB) && (idx == 0)) {
          slider.style.webkitTransition = 'left ' + stat.interval/2 + 'ms ease-in-out';
          slider.style.left = '200px';
        } else if((stat.posA > stat.posB) && (idx == len-1)) {
          slider.style.webkitTransition = 'left ' + stat.interval/2 + 'ms ease-in-out';
          slider.style.left = -idx * sWid - 200 + 'px';
        } else if(stat.posA < stat.posB) {
          idn = idx - 1;
          slider.style.webkitTransition = 'left ' + stat.interval + 'ms ease-in-out';
          slider.style.left = -idn * sWid + 'px';
        } else if(stat.posA > stat.posB) {
          idn = idx + 1;
          slider.style.webkitTransition = 'left ' + stat.interval + 'ms ease-in-out';
          slider.style.left = -idn * sWid + 'px';
        }
      } else {
        slider.style.webkitTransition = 'none';
        slider.style.left = -idx * sWid + stat.posB - stat.posA + 'px';
      }
    }
  };

  var end = function(e) {
    if(evt.start == 'mousedown' && stat.flag) {
      return false;
    }
    if(stat.thresholdB - stat.thresholdA < threshold.timer) {
      idx = idn;
      stat.interval = stat.interval/2;
    } else if((stat.posA - stat.posB > sWid/3) && (idx < len-1)) {
      idx++;
      stat.interval = stat.interval * (sWid - stat.posA + stat.posB) / sWid;
    } else if((stat.posB - stat.posA > sWid/3) && idx) {
      idx--;
      stat.interval = stat.interval * (sWid + stat.posA - stat.posB) / sWid;
    } else {
      stat.interval = stat.interval * Math.abs(stat.posA - stat.posB) / sWid;
    }
    flip(idx);
    stat = {'posA': 0, 'posB': 0, 'posM': 0, 'thresholdA': 0, 'thresholdB': 0, 'interval': 300, 'flag': true, 'evt': true};
  };

  var flip = function(n) {
    slider.style.webkitTransition = 'left ' + stat.interval + 'ms ease-in-out';
    slider.style.left = -n * sWid + 'px';
    frag.innerHTML = (n + 1) + ' / ' + len;
  };

  var resize = function() {
    sWid = ele.offsetWidth;
    slider.style.width = sWid * len + 'px';
    flip(idx);
  };

  var autoSlide = function() {
    idx == (len - 1) ? idx = 0 : idx++;
    flip(idx);
  };

  var init = function() {
    frag.innerHTML = 1 + ' / ' + len;
    ele.appendChild(frag);
    slider.style.width = sWid * len + 'px';
    ele.addEventListener(evt.start, start, false);
    ele.addEventListener(evt.move, move, false);
    document.addEventListener(evt.end, end, false);
    window.addEventListener('resize', resize, false);
    if(threshold.auto > -1) {
      auto = setInterval(autoSlide, threshold.auto);
    }
  };

  init();

}